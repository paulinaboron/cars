import com.fasterxml.uuid.Generators;
import com.google.gson.Gson;
import com.itextpdf.text.BaseColor;
import spark.Request;
import spark.Response;

import java.util.*;

import static spark.Spark.*;

public class App {
    public static ArrayList<Car> cars = new ArrayList<>();

    public static HashMap<String, BaseColor> colorsMap = new HashMap<>() {{
        put("red", BaseColor.RED);
        put("blue", BaseColor.BLUE);
        put("black", BaseColor.BLACK);
        put("green", BaseColor.GREEN);
    }};

    public static ArrayList<String> colors = new ArrayList<>() {
        {
            add("red");
            add("blue");
            add("black");
            add("green");
        }
    };
    public static ArrayList<String> models = new ArrayList<>() {
        {
            add("Toyota");
            add("Skoda");
            add("Mercedes");
            add("Audi");
            add("VW");
        }
    };

    public static void main(String[] args) {
        externalStaticFileLocation("C:\\Users\\4pa\\Desktop\\java\\sparkProject\\src\\main\\resources\\public");
//        externalStaticFileLocation("C:\\Users\\pauli\\Desktop\\java\\sparkProject\\src\\main\\resources\\public");
        post("/add", App::add);
        get("/json", App::getJson);
        post("/delete", App::delete);
        post("/generate", App::generate);
        post("/invoice", App::invoice);

    }

    static String add(Request req, Response res){
        System.out.println(req.body());
        Gson gson = new Gson();
        Car car = gson.fromJson(req.body(), Car.class);
        cars.add(car);
        System.out.println("car " + car.toString());
        res.type("application/json");
        return gson.toJson(car);
    }

    static String delete(Request req, Response res){
        System.out.println(req.body());
        Gson gson = new Gson();
        int id = gson.fromJson(req.body(), IdToDelete.class).getId();
        System.out.println(id);

        cars.removeIf(c -> c.id == id);
        res.type("application/json");
        return gson.toJson(cars);
    }

    static String getJson(Request req, Response res){
        res.type("application/json");
        Gson gson = new Gson();
        return gson.toJson(cars);
    }

    static String generate(Request req, Response res){
        for(int i=0; i<10; i++){
            Collections.shuffle(models);
            Collections.shuffle(colors);
            int year = (int) ((Math.random() * 10) + 2000);

            Random rd = new Random();
            ArrayList<Airbag> airbags = new ArrayList<>();
            airbags.add(new Airbag("kierowca", rd.nextBoolean()));
            airbags.add(new Airbag("pasażer", rd.nextBoolean()));
            airbags.add(new Airbag("kanapa", rd.nextBoolean()));
            airbags.add(new Airbag("boczne", rd.nextBoolean()));

            Car randomCar = new Car(models.get(0), year, colors.get(0), airbags);
            cars.add(randomCar);
        }
        return "ok";
    }

    static String invoice(Request req, Response res){
        Gson gson = new Gson();
        int id = gson.fromJson(req.body(), IdToDelete.class).getId();
        return "ok";
    }

}

class Airbag {
    String desc;
    boolean value;

    public Airbag(String name, boolean value) {
        this.desc = name;
        this.value = value;
    }

    @Override
    public String toString() {
        return "Airbag{" +
                "desc='" + desc + '\'' +
                ", value=" + value +
                '}';
    }
}

class Car{
    int id;
    UUID uuid;
    String model;
    int year;
    String color;
    ArrayList<Airbag> airbags;
    boolean invoice;

    public Car() {
        if (App.cars.isEmpty()) {
            this.id = 1;
        }else{
            this.id = App.cars.get(App.cars.size()-1).id + 1;
        }
        this.uuid = Generators.randomBasedGenerator().generate();
        this.invoice = false;
    }

    public Car( String model, int year, String color, ArrayList<Airbag> airbags) {
        if (App.cars.isEmpty()) {
            this.id = 1;
        }else{
            this.id = App.cars.get(App.cars.size()-1).id + 1;
        }
        this.uuid = Generators.randomBasedGenerator().generate();
        this.model = model;
        this.year = year;
        this.color = color;
        this.airbags = airbags;
        this.invoice = false;
    }

    public void setInvoice(boolean invoice) {
        this.invoice = invoice;
    }

    @Override
    public String toString() {
        return "Car{" +
                "id=" + id +
                ", uuid=" + uuid +
                ", model='" + model + '\'' +
                ", year=" + year +
                ", color='" + color + '\'' +
                ", airbags=" + airbags +
                '}';
    }
}

class IdToDelete{
    int id;

    public IdToDelete() {
    }

    public int getId() {
        return id;
    }
}
